package com.peerbits.creditCardNfcReader.enums;

public enum TagValueTypeEnum {
	BINARY, NUMERIC, TEXT, MIXED, DOL, TEMPLATE
}
