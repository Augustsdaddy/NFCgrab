# NFC Token & Credit Card reader 

This Project helps developer to read data from credit card: card number, expired date, card type , Read & Write data in NFC tocken.<br>

1. [Screenshots](#screenshots) <br>
2. [PlayStoreLink](#storelink) <br>
3. [License](#license) <br>
 
<b>Screenshots</b>
<p>
<img src="https://image.ibb.co/jqe3fL/1-1.png" alt="1-1" border="0"  width="200" height="350"/>
<img src="https://image.ibb.co/cQhpLL/1-2.png" alt="1-2" border="0"  width="200" height="350"/>
<img src="https://image.ibb.co/cfxdEf/1-3.png" alt="1-3" border="0"  width="200" height="350"/>
<img src="https://image.ibb.co/j7hBZf/1-5.png" alt="1-5" border="0"  width="200" height="350"/>
<img src="https://image.ibb.co/fXCpLL/1-10.png" alt="1-10" border="0" width="200" height="350"/>
<img src="https://image.ibb.co/bZmG0L/1-12.png" alt="1-12" border="0" width="200" height="350"/>
</p>
<br><br>
<b>PlayStoreLink</b>
<a href="https://play.google.com/store/apps/details?id=com.peerbits.nfccardread" target="_blank">https://play.google.com/store/apps/details?id=com.peerbits.nfccardread</a>



### License
The MIT License (MIT)

Copyright (c) 2018 Credit Card & NFC Token Reader 

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
